./cli.sh test
./cli.sh valid
./cli.sh train
