| | Long file | Small project (Gradle) | Big project (IntelliJ IDEA) |
| --- |--- | --- | --- | 
| Code2Vec (time) | 0.44 ± 0.07 sec | 27.15 ± 0.90 sec | 257.45 ± 18.89 sec |
| Code2Vec (allocated memory per sec) | 1.22 gb ± 188.22 mb | 1.08 gb ± 31.72 mb | 1.05 gb ± 78.83 mb |
| |  |  |  | 
| PathContext (time) | 0.63 ± 0.03 sec | 26.54 ± 1.25 sec | 223.76 ± 8.24 sec |
| PathContext (allocated memory per sec) | 1.16 gb ± 72.86 mb | 1.09 gb ± 51.89 mb | 1.12 gb ± 47.49 mb |
| |  |  |  | 
| ProjectParseCSV (time) | 0.33 ± 0.04 sec | 20.40 ± 1.12 sec | 180.37 ± 2.98 sec |
| ProjectParseCSV (allocated memory per sec) | 1.37 gb ± 180.29 mb | 1.19 gb ± 68.76 mb | 1.20 gb ± 20.16 mb |
| |  |  |  | 
| ProjectParseDOT (time) | 0.43 ± 0.05 sec | 32.98 ± 2.51 sec | 285.64 ± 3.04 sec |
| ProjectParseDOT (allocated memory per sec) | 1.23 gb ± 136.31 mb | 1.02 gb ± 78.14 mb | 1.06 gb ± 16.59 mb |
