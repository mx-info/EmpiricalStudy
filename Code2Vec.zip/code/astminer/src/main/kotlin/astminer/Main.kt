package astminer

import astminer.cli.*
import astminer.examples.code2vecCMethods

fun main(args: Array<String>) {
    code2vecCMethods(args[0])
}