package astminer.cli.util

fun languagesToString(languages: List<String>) = languages.joinToString(",")
