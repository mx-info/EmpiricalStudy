class ComplexArrayInitialization {

    private ComplexObject[] array;

    IntArrayInitialization() {
        array = new ComplexObject[1];
    }
}