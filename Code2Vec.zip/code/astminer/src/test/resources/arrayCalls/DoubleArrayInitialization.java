class DoubleArrayInitialization {

    private double[] array;

    IntArrayInitialization() {
        array = new double[1];
    }
}