class IntArrayInitialization {

    private int[] array;

    IntArrayInitialization() {
        array = new int[1];
    }
}