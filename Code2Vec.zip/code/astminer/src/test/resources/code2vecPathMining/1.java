class SingleFunction {
    void fun_withReallyLong_And_ComplicatedName(String[] args, int param) {
        System.out.println(" Hello again world!  ");
    }

    int Another_Fun_withReallyLong_And_ComplicatedName(String s)) {
        System.out.println(s);
    }
}
