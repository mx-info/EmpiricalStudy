class Foo {

    /**
     * Prints "bar'.
     */

    public static void foo() {
        System.out.println("bar");
    }


}

