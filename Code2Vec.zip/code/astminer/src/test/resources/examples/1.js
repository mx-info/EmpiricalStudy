var sum = function(a, b) {
    var result = a + b;
    return result;
};

alert(sum(1, 2));
alert('Hi everybody');