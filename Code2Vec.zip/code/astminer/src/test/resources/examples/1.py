x = 1
y = 2
z = 3
if x == 1:
    print(x, y, z)
    print("ololo")

def fun1(x, y):
    return x + y

def fun2(x, y):
    return x - y

def funSuperPuperShit(x, y, z):
    return x - y + z
