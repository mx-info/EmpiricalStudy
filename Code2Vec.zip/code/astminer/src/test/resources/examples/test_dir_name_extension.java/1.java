class SingleFunction {
    void fun(String[] args, int param) {
        System.out.println("Hello again world!");
    }
}
