class A {
    void hi() {
        String hi = "Hello";
        int a = 5;
        if (a > 0) {
            a = 0;
        }
    }


}

