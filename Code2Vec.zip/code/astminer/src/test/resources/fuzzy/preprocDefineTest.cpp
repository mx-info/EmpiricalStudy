#define form2(i, a, b) for (int i = (a); i < (b); ++i)
#define form(i, n) form2(i, 0, n)
form(i, 10) { }