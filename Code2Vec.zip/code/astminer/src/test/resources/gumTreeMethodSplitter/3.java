class SingleMethodInnerClass {
    class InnerClass {
        void main(String[] args) {
            System.out.println("Hello world!");
        }
    }
    void fun(String[] args, int param) {
        System.out.println("Hello again world!");
    }
}
