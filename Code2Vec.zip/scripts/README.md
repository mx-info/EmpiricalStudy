The entry point is `sbatch code2vec.job`.
