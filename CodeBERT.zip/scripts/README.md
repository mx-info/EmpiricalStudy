We reproduced the model on a Windows and a Linux machine.

- Windows entry point: the `.bat` file corresponding to the RQ.
- Linux entry point: `run.sh`.
