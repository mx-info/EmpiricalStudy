conda activate Devign38
export PYTHONPATH="$(dirname ${BASH_SOURCE[0]})"
export TS_SOCKET=/tmp/socket.devign
