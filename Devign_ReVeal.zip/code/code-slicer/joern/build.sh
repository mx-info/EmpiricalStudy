#!/bin/sh

gradle deploy -x test -x octopusTools -x octopusMlutils
