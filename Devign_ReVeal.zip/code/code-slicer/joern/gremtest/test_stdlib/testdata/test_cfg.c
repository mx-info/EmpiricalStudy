void popa_ex_2_5 ()
{
        x = a+b;
        y = a+b;
        while (y>a+b) {
                a = a + 1;
                x = a + b;
        }
}

void popa_ex_2_6 ()
{
	x = 5;
	y = 1;
	while (x>1) {
		y = x*y;
		x = x-1;
	}
}
