package ast.php.expressions;

import ast.expressions.Expression;

public class MagicConstant extends Expression
{
}
