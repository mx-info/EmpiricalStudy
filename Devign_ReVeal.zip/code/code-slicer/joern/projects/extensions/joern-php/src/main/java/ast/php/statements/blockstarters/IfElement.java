package ast.php.statements.blockstarters;

import ast.logical.statements.BlockStarter;

public class IfElement extends BlockStarter
{
}
