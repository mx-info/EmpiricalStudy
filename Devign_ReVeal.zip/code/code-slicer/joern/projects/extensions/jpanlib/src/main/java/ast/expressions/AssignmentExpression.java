package ast.expressions;

public class AssignmentExpression extends BinaryExpression
{
}
