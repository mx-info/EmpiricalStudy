package ast.expressions;

public class BitAndExpression extends BinaryOperationExpression
{
}
