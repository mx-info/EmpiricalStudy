package ast.expressions;

public class OrExpression extends BinaryOperationExpression
{
}
