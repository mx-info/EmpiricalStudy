package ddg.DefUseCFG;

public abstract class DefUseCFGFactory
{

	public abstract DefUseCFG create(Long funcId);

}
