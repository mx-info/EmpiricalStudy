long long BlockGroup::GetNextTimeCode() const
{
    return m_next;
}
