long long BlockGroup::GetPrevTimeCode() const
{
    return m_prev;
}
