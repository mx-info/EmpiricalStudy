unsigned long long Chapters::Atom::GetUID() const
{
    return m_uid;
}
