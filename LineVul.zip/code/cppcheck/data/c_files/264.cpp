CuePoint::~CuePoint()
{
    delete[] m_track_positions;
}
