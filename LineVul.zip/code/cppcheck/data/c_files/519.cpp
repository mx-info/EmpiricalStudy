const SeekHead* Segment::GetSeekHead() const
{
    return m_pSeekHead;
}
