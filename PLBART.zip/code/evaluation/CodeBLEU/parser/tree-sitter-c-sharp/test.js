console.log("Trying to require index.js in JavaScript");
require('.')
console.log("Require successfull");
