namespace World
{
    class Hello {
        static void Main(string []args)
        {
            Hello x = new Hello();
            System.Console.WriteLine("Hello, world.");
        }
    }

    interface Blah {

    }
}
