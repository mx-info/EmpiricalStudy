tree-sitter-go
===========================

[![Build/test](https://github.com/tree-sitter/tree-sitter-go/actions/workflows/ci.yml/badge.svg)](https://github.com/tree-sitter/tree-sitter-go/actions/workflows/ci.yml)

A [tree-sitter][] grammar for [Go](https://go.dev/ref/spec).

[tree-sitter]: https://github.com/tree-sitter/tree-sitter
