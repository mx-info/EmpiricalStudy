tree-sitter-php
==================

[![Build/test](https://github.com/tree-sitter/tree-sitter-php/actions/workflows/ci.yml/badge.svg)](https://github.com/tree-sitter/tree-sitter-php/actions/workflows/ci.yml)

PHP grammar for [tree-sitter][].

[tree-sitter]: https://github.com/tree-sitter/tree-sitter

