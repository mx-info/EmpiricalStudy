<?php


function a(array $b, Something $c) {
  //       ^ type.builtin
  //                  ^ type
  echo (int) $foo;
  //     ^ type.builtin
}
