def g(h, i, /, j, *, k=100, **kwarg):
    #       ^ operator
    #             ^ operator
    pass
