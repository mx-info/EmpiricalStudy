print "Ebra ka debra" 

while(true):
    print "CHol maferf uerh"