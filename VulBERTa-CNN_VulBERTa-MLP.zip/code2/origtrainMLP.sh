


# python Finetuning_VulBERTa-MLP.py \
#     --seed_input=201 \
#     --train_test=train \
#     --batch=3 \
#     --epochs=3 \
#     --dataset=combined

python Evaluation_VulBERTa-MLP.py \
    --seed_input=201 \
    --train_test=test \
    --batch=3 \
    --epochs=3 \
    --dataset=combined



