




 

python Finetuning_VulBERTa-MLP.py \
    --seed_input=666 \
    --data_folder="$1" \
    --save_folder="$2" \
    --train_test=train \
    --batch=3 \
    --epochs=2 \
    --dataset=combined



    
 