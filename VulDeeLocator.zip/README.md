# Model Reproduction

## To train and test, run the following slurmn command:

- Followed the code/README.md instructions to train and test the data
