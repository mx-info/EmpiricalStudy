Testcase ids and CVE ids of train dataset and test dataset.
